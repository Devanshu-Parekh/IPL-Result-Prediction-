import streamlit as st
import pandas as pd
import pickle

import sqlite3
conn = sqlite3.connect('data.db')
c = conn.cursor()

# app = login.py

teams = ['Sunrisers Hyderabad',
         'Mumbai Indians',
         'Royal Challengers Bangalore',
         'Kolkata Knight Riders',
         'Kings XI Punjab',
         'Chennai Super Kings',
         'Rajasthan Royals',
         'Delhi Capitals']

cities = ['Hyderabad', 'Bangalore', 'Mumbai', 'Indore', 'Kolkata', 'Delhi',
          'Chandigarh', 'Jaipur', 'Chennai', 'Cape Town', 'Port Elizabeth',
          'Durban', 'Centurion', 'East London', 'Johannesburg', 'Kimberley',
          'Bloemfontein', 'Ahmedabad', 'Cuttack', 'Nagpur', 'Dharamsala',
          'Visakhapatnam', 'Pune', 'Raipur', 'Ranchi', 'Abu Dhabi',
          'Sharjah', 'Mohali', 'Bengaluru']


def create_usertable():
    c.execute('CREATE TABLE IF NOT EXISTS usertable(username TEXT,password TEXT)')

def add_userdata(username,password):
    c.execute('INSERT INTO usertable(username,password) VALUES (?,?)',(username,password))
    conn.commit()

def login_user(username,password):
    c.execute('SELECT * FROM usertable WHERE username =? AND password = ?',(username,password))
    data = c.fetchall()
    return data

def view_all_users(username,password):
    c.execute('SELECT * FROM usertable WHERE username =? AND password =?',(username,password))
    data = c.fetchall()
    return data

def main():
    """Simple Login Page"""

    # st.title("Simple Login App")
    menu = ["Home", "Login", "SignUp"]
    choice = st.sidebar.selectbox("Menu",menu)

    if choice == "Home":
        st.subheader("Home")
    elif choice == "Login":
        # st.subheader("Login Section")

        # st.subheader("Login Section")
        username = st.sidebar.text_input("User Name")
        password = st.sidebar.text_input("Password",type='password')
        if st.sidebar.checkbox("Login"):
            create_usertable()
            result = login_user(username,password)
            if result:

                st.success("Logged In as {}".format(username))

                task = st.selectbox("Task",["Predict the win percentage","Profile"])
                if task == "Predict the win percentage":
                    st.subheader("Predict Win Percentage")
                    # app.add_app("Predict App",app.py)

                    pipe = pickle.load(open("pipe.pkl", "rb"))
                    st.title('IPL Match Win Predictor')
                    col1, col2 = st.columns(2)

                    with col1:
                        batting_team = st.selectbox('Select the batting team', sorted(teams))
                    with col2:
                        bowling_team = st.selectbox('Select the bowling team', sorted(teams))

                    if bowling_team == batting_team:
                        st.header('Invalid bowling team. Please select different bowling team.')

                    selected_city = st.selectbox('Select host city', sorted(cities))

                    target = st.number_input('Target')
                    target <= 300

                    col3, col4, col5 = st.columns(3)

                    with col3:
                        score = st.number_input('Score')
                    with col4:
                        overs = st.number_input('Overs completed')
                    with col5:
                        wickets = st.number_input('Wickets out')
                        wickets == int

                    if st.button('Predict Probability'):
                        runs_left = target - score
                        balls_left = 120 - (overs * 6)
                        wickets = 10 - wickets
                        crr = score / overs
                        rrr = (runs_left * 6) / balls_left

                        input_df = pd.DataFrame(
                            {'batting_team': [batting_team], 'bowling_team': [bowling_team], 'city': [selected_city],
                             'runs_left': [runs_left], 'balls_left': [balls_left], 'wickets': [wickets],
                             'total_runs_x': [target], 'crr': [crr], 'rrr': [rrr]})

                        result = pipe.predict_proba(input_df)
                        loss = result[0][0]
                        win = result[0][1]
                        st.header(batting_team + "- " + str(round(win * 100)) + "%")
                        st.header(bowling_team + "- " + str(round(loss * 100)) + "%")

                elif task == "Profile":
                    st.subheader("User Profile")
                    user_result = view_all_users(username,password)
                    clean_db = pd.DataFrame(user_result,columns=["Username","Password"])
                    st.dataframe(clean_db)

                else:
                    st.warning("Incorrect Username/Password")


    elif choice == "SignUp":
        st.subheader("Create New Account")
        new_user = st.text_input("Username")
        new_password = st.text_input("Password",type='password')

        if st.button("Signup"):
            create_usertable()
            add_userdata(new_user , new_password)
            st.success("You have successfully create a valid account")
            st.info("Go to Login Menu to Login")


if __name__ == '__main__':
    main()